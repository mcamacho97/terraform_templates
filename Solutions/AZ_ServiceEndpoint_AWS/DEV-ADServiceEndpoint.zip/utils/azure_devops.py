"""Modules"""
import logging
import json
import base64
import requests

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class AzureDevops:
    def __init__(self):
        self.personal_access_token = "rgizcu5tajnr6fbkeeddmkbuplpa5m3mf6cu4dqmxrs35j6m4wma" #ENVIRONMENT VARIABLE
        self.authorization = str(base64.b64encode(bytes(f':{self.personal_access_token}', 'ascii')), 'ascii')

    def get_project_names(self, organization_url):
        authorization = self.authorization
        headers = {
            'Accept': 'application/json',
            'Authorization': f'Basic {authorization}'
        }
        # Get the list of projects in the org
        project_names = []
        response = requests.get(url=organization_url, headers=headers, timeout=30)
        projects = response.__dict__["_content"].decode('utf-8')
        logger.info(f"Projects response {projects}")
        json_data = json.loads(projects)
        values = json_data["value"]
        for value in values:
            project_names.append(value['name'])
        print(project_names)
        return project_names

    def get_collections(self, organization_url):
        authorization = self.authorization
        headers = {
            'Accept': 'application/json',
            'Authorization': f'Basic {authorization}'
        }
        # Get the list of collections in the org
        collections_names = []
        response = requests.get(url=organization_url, headers=headers, timeout=30)
        print(response)
        collections = response.__dict__["_content"].decode('utf-8')
        logger.info(f"Collections response {collections}")
        json_data = json.loads(collections)
        values = json_data["value"]
        for value in values:
            collections_names.append(value['name'])
        print(collections_names)
        return collections_names

    def get_service_endpoints(self, organization_url):
        authorization = self.authorization
        headers = {
            'Accept': 'application/json',
            'Authorization': f'Basic {authorization}'
        }
        # Get the list of service endpoints in the org
        service_endpoints = []
        response = requests.get(url=organization_url, headers=headers, timeout=30)
        service_endpoint = response.__dict__["_content"].decode('utf-8')
        logger.info(f"Service endpoint response {service_endpoint}")
        json_data = json.loads(service_endpoint)
        values = json_data['value']
        for value in values:
            # if value['type'] == "AWSServiceEndpoint" and value['name']:
            if value['type'] == "AWSServiceEndpoint" and value['name'] == "ServiceConnection_Test":
                service_endpoints.append(value['id'])
        print(service_endpoints)
        return service_endpoints
    
    def update_service_endpoint(self, organization_url):
        authorization = self.authorization
        headers = {
            'Accept': 'application/json',
            'Authorization': f'Basic {authorization}'
        }
        # Get the list of service endpoints in the org
        service_endpoints = []
        response = requests.get(url=organization_url, headers=headers, timeout=30)
        service_endpoint = response.__dict__["_content"].decode('utf-8')
        logger.info(f"Service endpoint response {service_endpoint}")
        json_data = json.loads(service_endpoint)
        values = json_data['value']
        for value in values:
            # if value['type'] == "AWSServiceEndpoint" and value['name']:
            if value['type'] == "AWSServiceEndpoint" and value['name'] == "ServiceConnection_Test":
                service_endpoints.append(value['id'])
        print(service_endpoints)
        return service_endpoints

def main(): 
    API_URL_COLLECTION = "http://ni-cfl-dvps-1a/_apis/projects?api-version=5.0"
    API_URL_PROJECT = "http://ni-cfl-dvps-1a/BLNI-Gerencia%20Infraestructura/_apis/projects?api-version=5.0" # ENV VARIABLE
    API_URL_GET_SERVICE_ENDPOINTS= "http://ni-cfl-dvps-1a/BLNI-Gerencia%20Infraestructura/LAFISE%20IaC/_apis/serviceendpoint/endpoints?api-version=5.0-preview.2" # ENV VARIABLE
    API_URL_UPDATE_SERVICE_ENDPOINTS = "http://ni-cfl-dvps-1a/BLNI-Gerencia%20Infraestructura/LAFISE%20IaC/_apis/serviceendpoint/endpoints/{test}?api-version=5.0-preview.2"
    azure_object = AzureDevops()

    print("-------------------INFORMACIÓN DE COLLECTIONS------------------")
    azure_object.get_collections(API_URL_COLLECTION)
    print("-------------------INFORMACIÓN DE PROYECTOS------------------")
    azure_object.get_project_names(API_URL_PROJECT)
    print("-------------------INFORMACIÓN DE SERVICE ENDPOINTS------------------")
    test = azure_object.get_service_endpoints(API_URL_GET_SERVICE_ENDPOINTS)
    azure_object.update_service_endpoint(API_URL_UPDATE_SERVICE_ENDPOINTS)


if __name__ == "__main__":
    main()