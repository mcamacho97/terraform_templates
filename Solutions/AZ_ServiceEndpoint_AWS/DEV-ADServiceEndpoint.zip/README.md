# DEV-ADServiceEndpoint

Lambda function to automatic update Azure DevOps service endpoints AWSType to get new programmatic access
## Authors

- [@mcamacho97](https://github.com/mcamacho97)


## 🔗 Links

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/mcamacho-dev/)


