import boto3
import json
from pprint import pprint
import logging
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def get_secret_manager(secret_name):
    secret = boto3.client('secretsmanager')

    try:
        secret.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        logger.info(e)
        return f"{secret_name} secret can not be obtained: \n{e}"

    access_aws = secret['SecretString']
    json_access_aws = json.loads(access_aws)
    print(secret)
    return json_access_aws

def lambda_handler(event, context):
    print("-------------------Access y Secret Access keys------------------")
    get_secret_manager("workshop/secret_manager") #os.environ
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "hello world",
        }),
    }

if __name__ == "__main__":
    lambda_handler(event='', context='')
